package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamiliesScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedLocalityId by remember { mutableStateOf(0) }
    var selectedShelterStatus by remember { mutableStateOf("") }
    var selectedFamilyForDetails by remember { mutableStateOf<FamilyEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val familiesFlow = remember(searchQuery, selectedLocalityId, selectedShelterStatus) {
        repository.getFamilies(searchQuery, selectedLocalityId, if (selectedShelterStatus.isEmpty()) null else selectedShelterStatus)
    }
    val families by familiesFlow.collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سجل الأسر والمستفيدين", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة أسرة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة أسرة")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // مربع البحث المتقدم
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("بحث بالاسم أو برقم الهوية الوطنية...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // شريط تصفية المحليات
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterChip(
                    selected = selectedLocalityId == 0,
                    onClick = { selectedLocalityId = 0 },
                    label = { Text("كل المحليات") }
                )
                localities.take(4).forEach { loc ->
                    val isPermitted = repository.canAccessLocality(loc.LocalityID)
                    FilterChip(
                        selected = selectedLocalityId == loc.LocalityID,
                        onClick = {
                            if (isPermitted) selectedLocalityId = loc.LocalityID
                        },
                        enabled = isPermitted,
                        label = { Text(loc.LocalityName) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "عدد النتائج: ${families.size} أسرة مسجلة",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // قائمة البطاقات
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(families, key = { it.familyID }) { family ->
                    FamilyCardItem(
                        family = family,
                        localityName = localities.find { it.LocalityID == family.localityID }?.LocalityName ?: "محلية #${family.localityID}",
                        onClick = { selectedFamilyForDetails = family },
                        onDelete = {
                            scope.launch {
                                repository.deleteFamily(family)
                            }
                        }
                    )
                }
            }
        }
    }

    // نافذة تفاصيل الأسرة الكاملة
    if (selectedFamilyForDetails != null) {
        val f = selectedFamilyForDetails!!
        AlertDialog(
            onDismissRequest = { selectedFamilyForDetails = null },
            title = {
                Text(
                    text = f.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DetailRow("رقم الهوية:", f.nationalID)
                    DetailRow("عدد الأفراد:", "${f.familyMembersCount} أفراد")
                    DetailRow("الحالة الاجتماعية:", "${f.maritalStatus} (${f.gender})")
                    DetailRow("الزوجة:", f.wifeName ?: "غير مسجل")
                    DetailRow("اعتماد التنمية:", f.developmentApproval)
                    DetailRow("اعتماد الأشغال:", f.worksApproval)
                    DetailRow("حالة الإقامة:", f.residentStatus)
                    DetailRow("نوع الضرر:", f.damageType)
                    DetailRow("حالة الإيواء:", f.shelterStatus)
                    DetailRow("ملاحظات:", f.notes ?: "لا توجد")
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedFamilyForDetails = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // نافذة إضافة أسرة جديدة
    if (showAddDialog) {
        AddFamilyDialog(
            localities = localities,
            onDismiss = { showAddDialog = false },
            onSave = { newFamily ->
                scope.launch {
                    repository.insertFamily(newFamily)
                    showAddDialog = false
                }
            }
        )
    }
}

@Composable
fun FamilyCardItem(
    family: FamilyEntity,
    localityName: String,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = family.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${family.familyMembersCount} أفراد",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "هوية: ${family.nationalID}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = "• المحلية: $localityName",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusTag(text = family.developmentApproval, color = Color(0xFF10B981))
                StatusTag(text = family.shelterStatus, color = Color(0xFF0284C7))
                StatusTag(text = family.damageType, color = Color(0xFFF59E0B))
            }
        }
    }
}

@Composable
fun StatusTag(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = color,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun AddFamilyDialog(
    localities: List<com.humanitarian.aidmanagement.data.local.entities.LocalityEntity>,
    onDismiss: () -> Unit,
    onSave: (FamilyEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }
    var membersCount by remember { mutableStateOf("6") }
    var selectedLocalityId by remember { mutableStateOf(localities.firstOrNull()?.LocalityID ?: 1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة أسرة جديدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم رب الأسرة رباعي") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nationalId,
                    onValueChange = { nationalId = it },
                    label = { Text("رقم الهوية (9 أرقام)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = membersCount,
                    onValueChange = { membersCount = it },
                    label = { Text("عدد أفراد الأسرة") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && nationalId.isNotBlank()) {
                        val newFamily = FamilyEntity(
                            name = name,
                            nationalID = nationalId,
                            birthDate = "1980-01-01",
                            gender = "ذكر",
                            maritalStatus = "متزوج",
                            familyMembersCount = membersCount.toIntOrNull() ?: 6,
                            developmentApproval = "معتمد",
                            localityApproval = "معتمد",
                            worksApproval = "معتمد أشغال",
                            residentStatus = "مقيم",
                            damageType = "أضرار كلية",
                            shelterStatus = "إيواء داخلي",
                            localityID = selectedLocalityId
                        )
                        onSave(newFamily)
                    }
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
