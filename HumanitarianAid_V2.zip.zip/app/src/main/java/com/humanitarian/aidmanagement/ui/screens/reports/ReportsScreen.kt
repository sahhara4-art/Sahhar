package com.humanitarian.aidmanagement.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.util.DistributionPdfReportData
import com.humanitarian.aidmanagement.util.PdfReportExporter
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val pdfExporter = remember { PdfReportExporter(context) }
    var stats by remember { mutableStateOf<DashboardStats?>(null) }
    var selectedReportType by remember { mutableStateOf("الأسر") }
    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }
    var generatedPdfFile by remember { mutableStateOf<File?>(null) }
    var isGeneratingPdf by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        stats = repository.getDashboardStats()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("التقارير وتصدير المستندات (PDF)", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "توليد كشوفات التوزيع وتقارير PDF الرسمية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "استخراج مستندات PDF معتمدة تتضمن جداول المستلمين ومربعات التوقيع والبصمة، مع دعم الطباعة المباشرة والمشاركة الميدانية.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("الأسر", "المرشحين", "المستفيدين", "المحليات").forEach { type ->
                                FilterChip(
                                    selected = selectedReportType == type,
                                    onClick = { selectedReportType = type },
                                    label = { Text("تقرير $type") }
                                )
                            }
                        }
                    }
                }
            }

            // إشعار نجاح توليد الـ PDF مع أزرار المشاركة والطباعة
            if (generatedPdfFile != null) {
                item {
                    val file = generatedPdfFile!!
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.15f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFF10B981))
                                Column {
                                    Text(
                                        text = "تم إنشاء مستند الـ PDF بنجاح!",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color(0xFF10B981)
                                    )
                                    Text(
                                        text = "${file.name} (${file.length() / 1024} KB)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { pdfExporter.sharePdfReport(file) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("مشاركة المستند", style = MaterialTheme.typography.bodySmall)
                                }

                                Button(
                                    onClick = { pdfExporter.printPdfReport(file) },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("طباعة فورية", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            } else if (exportSuccessMessage != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                    ) {
                        Text(
                            text = exportSuccessMessage ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // 1. بطاقة تقرير كشف توزيع المساعدات الميداني (PDF)
            item {
                PdfReportCard(
                    title = "كشف توزيع المساعدات الميداني (PDF)",
                    description = "كشف رسمي جاهز للطباعة والتوقيع يتضمن أرقام الهويات ومربعات البصمة لـ ${stats?.totalSelectedCandidates ?: 0} مرشح",
                    badge = "مستند رسمي PDF",
                    icon = Icons.Default.PictureAsPdf,
                    color = Color(0xFF0D9488),
                    isLoading = isGeneratingPdf,
                    onExportPdf = {
                        scope.launch {
                            isGeneratingPdf = true
                            try {
                                val candidates = repository.runNomination(null, 1, 1L, 50)
                                val reportData = DistributionPdfReportData(
                                    reportTitle = "كشف توزيع المساعدات الإنسانية الميداني",
                                    projectName = "مشروع الإغاثة العاجلة وتوزيع الطرود",
                                    aidTypeName = "غذائي",
                                    localityName = "جميع المحليات المعتمدة",
                                    date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                    supervisorName = repository.getCurrentUser()?.FullName ?: "مشرف التوزيع الميداني",
                                    candidates = candidates
                                )
                                val file = pdfExporter.generateDistributionReportPdf(reportData)
                                generatedPdfFile = file
                                exportSuccessMessage = "تم توليد ملف PDF بنجاح."
                            } catch (e: Exception) {
                                exportSuccessMessage = "خطأ أثناء توليد PDF: ${e.localizedMessage}"
                            } finally {
                                isGeneratingPdf = false
                            }
                        }
                    }
                )
            }

            // 2. تقرير الأسر الشامل
            item {
                PdfReportCard(
                    title = "تقرير الأسر الشامل حسب المحلية والحالة (PDF)",
                    description = "بيانات ${stats?.totalFamilies ?: 0} أسرة مسجلة في Room Database مع أرقام الهويات وحالة الإيواء",
                    badge = "سجل الأسر",
                    icon = Icons.Default.FamilyRestroom,
                    color = Color(0xFF0284C7),
                    isLoading = isGeneratingPdf,
                    onExportPdf = {
                        scope.launch {
                            isGeneratingPdf = true
                            try {
                                val candidates = repository.runNomination(null, 1, 1L, 40)
                                val reportData = DistributionPdfReportData(
                                    reportTitle = "تقرير حصر الأسر والمستفيدين الشامل",
                                    projectName = "حصر وتحديث بيانات الأسر الميدانية",
                                    aidTypeName = "بيانات عامة",
                                    localityName = "كافة المحليات",
                                    date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                    supervisorName = repository.getCurrentUser()?.FullName ?: "إدارة المنظومة",
                                    candidates = candidates
                                )
                                val file = pdfExporter.generateDistributionReportPdf(reportData)
                                generatedPdfFile = file
                            } finally {
                                isGeneratingPdf = false
                            }
                        }
                    }
                )
            }

            // 3. تقرير المستفيدين وسجلات الاستلام الفعلية
            item {
                PdfReportCard(
                    title = "ملخص المستفيدين وسندات الصرف الميدانية (PDF)",
                    description = "سجلات المساعدات المسلمة ${stats?.totalAidRecords ?: 0} والمستودعات ومطابقة المستلمين",
                    badge = "سندات صرف",
                    icon = Icons.Default.FactCheck,
                    color = Color(0xFF8B5CF6),
                    isLoading = isGeneratingPdf,
                    onExportPdf = {
                        scope.launch {
                            isGeneratingPdf = true
                            try {
                                val candidates = repository.runNomination(null, 1, 1L, 30)
                                val reportData = DistributionPdfReportData(
                                    reportTitle = "سند صرف وتوزيع المساعدات المستلمة",
                                    projectName = "مشروع الكسوة والفرشات الشتوية",
                                    aidTypeName = "فرشات وشوادر",
                                    localityName = "المستودع الرئيسي",
                                    date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                    supervisorName = "أمين المستودع المركزي",
                                    candidates = candidates
                                )
                                val file = pdfExporter.generateDistributionReportPdf(reportData)
                                generatedPdfFile = file
                            } finally {
                                isGeneratingPdf = false
                            }
                        }
                    }
                )
            }

            // 4. تقرير نسب وتوزيع المحليات
            item {
                PdfReportCard(
                    title = "تقرير نسب وتوزيع المحليات (PDF)",
                    description = "مقارنة الحصص والنسب المئوية المستهدفة بخوارزمية أكبر الكسور مع الأعداد الموزعة",
                    badge = "توزيع جغرافي",
                    icon = Icons.Default.PieChart,
                    color = Color(0xFFF59E0B),
                    isLoading = isGeneratingPdf,
                    onExportPdf = {
                        scope.launch {
                            isGeneratingPdf = true
                            try {
                                val candidates = repository.runNomination(null, 1, 1L, 25)
                                val reportData = DistributionPdfReportData(
                                    reportTitle = "تقرير التوزيع الجغرافي لحصص المحليات",
                                    projectName = "توزيع المساعدات حسب نسب المحليات المعتمدة",
                                    aidTypeName = "غذائي",
                                    localityName = "الرمال، الشيخ رضوان، الشاطئ، مشروع عامر",
                                    date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                    supervisorName = "لجنة التوزيع المشتركة",
                                    candidates = candidates
                                )
                                val file = pdfExporter.generateDistributionReportPdf(reportData)
                                generatedPdfFile = file
                            } finally {
                                isGeneratingPdf = false
                            }
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun PdfReportCard(
    title: String,
    description: String,
    badge: String,
    icon: ImageVector,
    color: Color,
    isLoading: Boolean,
    onExportPdf: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .background(color.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Text(text = description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onExportPdf,
                enabled = !isLoading,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = color),
                modifier = Modifier.fillMaxWidth().height(42.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                } else {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تصدير وطباعة تقرير PDF")
                }
            }
        }
    }
}
