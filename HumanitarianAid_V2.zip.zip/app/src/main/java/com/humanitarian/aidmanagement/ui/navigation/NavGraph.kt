package com.humanitarian.aidmanagement.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Login : Screen("login", "تسجيل الدخول")
    object Dashboard : Screen("dashboard", "المؤشرات العامة والتقارير")
    object Families : Screen("families", "بيانات الأسر")
    object Children : Screen("children", "سجل الأطفال")
    object Nomination : Screen("nomination", "ترشيح المساعدات")
    object ManualSelection : Screen("manual_selection", "الترشيح اليدوي")
    object NominationResults : Screen("nomination_results", "نتائج الترشيح")
    object Projects : Screen("projects", "المشاريع الإنسانية")
    object Reports : Screen("reports", "التقارير والإحصائيات")
    object Settings : Screen("settings", "إعدادات المنظومة")
    object BackupRestore : Screen("backup_restore", "النسخ الاحتياطي واستعادة البيانات")
}
