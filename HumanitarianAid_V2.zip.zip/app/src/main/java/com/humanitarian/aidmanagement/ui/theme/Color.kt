package com.humanitarian.aidmanagement.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald800 = Color(0xFF065F46)
val Emerald700 = Color(0xFF047857)
val Emerald600 = Color(0xFF059669)
val Emerald500 = Color(0xFF10B981)

val Slate950 = Color(0xFF020617)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate300 = Color(0xFFCBD5E1)
val Slate100 = Color(0xFFF1F5F9)

val Amber500 = Color(0xFFF59E0B)
val Rose500 = Color(0xFFF43F5E)
val Sky500 = Color(0xFF0EA5E9)
val Indigo500 = Color(0xFF6366F1)
