package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * معلومات النسخة الاحتياطية
 */
data class BackupMetadata(
    val exportDate: String,
    val timestamp: Long,
    val appVersion: String = "1.0.0",
    val totalFamilies: Int,
    val totalChildren: Int,
    val totalAidRecords: Int,
    val totalProjects: Int
)

data class BackupResult(
    val success: Boolean,
    val message: String,
    val filePath: String? = null,
    val fileSizeKb: Long = 0,
    val metadata: BackupMetadata? = null
)

/**
 * مدير النسخ الاحتياطي لقاعدة بيانات Room محلياً (JSON & SQL)
 */
class DatabaseBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())

    /**
     * تصدير قاعدة البيانات كاملة إلى ملف JSON منظم
     */
    suspend fun exportToJson(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()

            // 1. جلب البيانات من كافة الجداول
            val families = database.familyDao().getAllFamilies().first()
            val children = database.childDao().searchChildren("").first()
            val aidTypes = database.aidTypeDao().getAllActiveAidTypes().first()
            val projects = database.projectDao().getAllActiveProjects().first()
            val aidRecords = database.aidRecordDao().getAllAidRecords().first()
            val localities = database.localityDao().getAllLocalities().first()
            val distributions = database.localityDao().getDistributions().first()
            val settings = database.systemSettingDao().getAllSettings().first()
            val users = database.userDao().getAllUsers().first()

            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))

            // 2. ترويسة النسخة الاحتياطية
            val metaObj = JSONObject().apply {
                put("systemName", "نظام إدارة المساعدات الإنسانية")
                put("packageName", "com.humanitarian.aidmanagement")
                put("exportDate", dateStr)
                put("timestamp", now)
                put("version", "1.0.0")
                put("familiesCount", families.size)
                put("childrenCount", children.size)
                put("aidRecordsCount", aidRecords.size)
                put("projectsCount", projects.size)
            }
            root.put("metadata", metaObj)

            // 3. جدول الأسر
            val familiesArray = JSONArray()
            families.forEach { f ->
                val obj = JSONObject().apply {
                    put("familyID", f.familyID)
                    put("name", f.name)
                    put("nationalID", f.nationalID)
                    put("birthDate", f.birthDate)
                    put("gender", f.gender)
                    put("maritalStatus", f.maritalStatus)
                    put("familyMembersCount", f.familyMembersCount)
                    put("wifeName", f.wifeName ?: "")
                    put("wifeNationalID", f.wifeNationalID ?: "")
                    put("deathStatus", f.deathStatus)
                    put("developmentApproval", f.developmentApproval)
                    put("localityApproval", f.localityApproval)
                    put("worksApproval", f.worksApproval)
                    put("residentStatus", f.residentStatus)
                    put("damageType", f.damageType)
                    put("shelterStatus", f.shelterStatus)
                    put("localityID", f.localityID)
                    put("notes", f.notes ?: "")
                    put("createdDate", f.createdDate)
                }
                familiesArray.put(obj)
            }
            root.put("families", familiesArray)

            // 4. جدول الأطفال
            val childrenArray = JSONArray()
            children.forEach { c ->
                val obj = JSONObject().apply {
                    put("childID", c.childID)
                    put("nationalID", c.nationalID)
                    put("childName", c.childName)
                    put("birthDate", c.birthDate)
                    put("gender", c.gender)
                    put("familyNationalID", c.familyNationalID)
                    put("localityID", c.localityID)
                    put("shelterStatus", c.shelterStatus)
                }
                childrenArray.put(obj)
            }
            root.put("children", childrenArray)

            // 5. أنواع المساعدات
            val aidTypesArray = JSONArray()
            aidTypes.forEach { a ->
                val obj = JSONObject().apply {
                    put("aidTypeID", a.aidTypeID)
                    put("aidTypeName", a.aidTypeName)
                    put("description", a.description)
                    put("defaultExclusionDays", a.defaultExclusionDays)
                }
                aidTypesArray.put(obj)
            }
            root.put("aid_types", aidTypesArray)

            // 6. المشاريع
            val projectsArray = JSONArray()
            projects.forEach { p ->
                val obj = JSONObject().apply {
                    put("projectID", p.projectID)
                    put("projectNumber", p.projectNumber)
                    put("projectName", p.projectName)
                    put("aidTypeID", p.aidTypeID)
                    put("detailedDescription", p.detailedDescription)
                    put("projectDate", p.projectDate)
                    put("fundingInstitution", p.fundingInstitution)
                    put("quantity", p.quantity)
                }
                projectsArray.put(obj)
            }
            root.put("projects", projectsArray)

            // 7. سجلات المساعدات
            val aidRecordsArray = JSONArray()
            aidRecords.forEach { r ->
                val obj = JSONObject().apply {
                    put("aidRecordID", r.aidRecordID)
                    put("familyID", r.familyID)
                    put("aidTypeID", r.aidTypeID)
                    put("projectID", r.projectID)
                    put("aidDate", r.aidDate)
                    put("selectionDate", r.selectionDate)
                    put("recipientStatus", r.recipientStatus)
                    put("warehouse", r.warehouse)
                    put("aidValue", r.aidValue)
                }
                aidRecordsArray.put(obj)
            }
            root.put("aid_records", aidRecordsArray)

            // 8. حفظ الملف في التخزين المحلي للتطبيق
            val backupDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
            val fileName = "HumanitarianAid_Backup_${dateFormat.format(Date(now))}.json"
            val file = File(backupDir, fileName)

            FileOutputStream(file).use { fos ->
                fos.write(root.toString(2).toByteArray(Charsets.UTF_8))
            }

            BackupResult(
                success = true,
                message = "تم إنشاء النسخة الاحتياطية بنجاح بصيغة JSON",
                filePath = file.absolutePath,
                fileSizeKb = file.length() / 1024,
                metadata = BackupMetadata(
                    exportDate = dateStr,
                    timestamp = now,
                    totalFamilies = families.size,
                    totalChildren = children.size,
                    totalAidRecords = aidRecords.size,
                    totalProjects = projects.size
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "حدث خطأ أثناء تصدير النسخة الاحتياطية: ${e.localizedMessage}"
            )
        }
    }

    /**
     * تصدير قاعدة البيانات كأوامر SQL Dump جاهزة للاستيراد
     */
    suspend fun exportToSql(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val sb = StringBuilder()
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))

            sb.append("-- ========================================================\n")
            sb.append("-- نظام إدارة المساعدات الإنسانية - نسخة احتياطية SQL Dump\n")
            sb.append("-- تاريخ التصدير: $dateStr\n")
            sb.append("-- ========================================================\n\n")

            sb.append("BEGIN TRANSACTION;\n\n")

            // الأسر
            val families = database.familyDao().getAllFamilies().first()
            sb.append("-- تفريغ بيانات جدول الأسر (${families.size} أسرة)\n")
            families.forEach { f ->
                val name = f.name.replace("'", "''")
                val notes = (f.notes ?: "").replace("'", "''")
                val wife = (f.wifeName ?: "").replace("'", "''")
                sb.append("INSERT OR REPLACE INTO families (familyID, name, nationalID, birthDate, gender, maritalStatus, familyMembersCount, wifeName, wifeNationalID, deathStatus, developmentApproval, localityApproval, worksApproval, residentStatus, damageType, shelterStatus, localityID, notes, createdDate) ")
                sb.append("VALUES (${f.familyID}, '$name', '${f.nationalID}', '${f.birthDate}', '${f.gender}', '${f.maritalStatus}', ${f.familyMembersCount}, '$wife', '${f.wifeNationalID ?: ""}', '${f.deathStatus}', '${f.developmentApproval}', '${f.localityApproval}', '${f.worksApproval}', '${f.residentStatus}', '${f.damageType}', '${f.shelterStatus}', ${f.localityID}, '$notes', ${f.createdDate});\n")
            }
            sb.append("\n")

            // الأطفال
            val children = database.childDao().searchChildren("").first()
            sb.append("-- تفريغ بيانات جدول الأطفال (${children.size} طفل)\n")
            children.forEach { c ->
                val name = c.childName.replace("'", "''")
                sb.append("INSERT OR REPLACE INTO children (childID, nationalID, childName, birthDate, gender, familyNationalID, localityID, shelterStatus) ")
                sb.append("VALUES (${c.childID}, '${c.nationalID}', '$name', '${c.birthDate}', '${c.gender}', '${c.familyNationalID}', ${c.localityID}, '${c.shelterStatus}');\n")
            }
            sb.append("\n")

            // المشاريع وسجلات المساعدات
            val projects = database.projectDao().getAllActiveProjects().first()
            projects.forEach { p ->
                val pName = p.projectName.replace("'", "''")
                val pDesc = p.detailedDescription.replace("'", "''")
                val pFund = p.fundingInstitution.replace("'", "''")
                sb.append("INSERT OR REPLACE INTO projects (projectID, projectNumber, projectName, aidTypeID, detailedDescription, projectDate, fundingInstitution, quantity, isActive) ")
                sb.append("VALUES (${p.projectID}, '${p.projectNumber}', '$pName', ${p.aidTypeID}, '$pDesc', '${p.projectDate}', '$pFund', ${p.quantity}, 1);\n")
            }

            val records = database.aidRecordDao().getAllAidRecords().first()
            records.forEach { r ->
                sb.append("INSERT OR REPLACE INTO aid_records (aidRecordID, familyID, aidTypeID, projectID, aidDate, selectionDate, recipientStatus, warehouse, aidValue) ")
                sb.append("VALUES (${r.aidRecordID}, ${r.familyID}, ${r.aidTypeID}, ${r.projectID}, '${r.aidDate}', '${r.selectionDate}', '${r.recipientStatus}', '${r.warehouse}', ${r.aidValue});\n")
            }

            sb.append("\nCOMMIT;\n")

            val backupDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
            val fileName = "HumanitarianAid_Dump_${dateFormat.format(Date(now))}.sql"
            val file = File(backupDir, fileName)

            FileOutputStream(file).use { fos ->
                fos.write(sb.toString().toByteArray(Charsets.UTF_8))
            }

            BackupResult(
                success = true,
                message = "تم إنشاء ملف تفريغ SQL Dump بنجاح",
                filePath = file.absolutePath,
                fileSizeKb = file.length() / 1024,
                metadata = BackupMetadata(
                    exportDate = dateStr,
                    timestamp = now,
                    totalFamilies = families.size,
                    totalChildren = children.size,
                    totalAidRecords = records.size,
                    totalProjects = projects.size
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "حدث خطأ أثناء تصدير ملف SQL: ${e.localizedMessage}"
            )
        }
    }

    /**
     * استعادة قاعدة البيانات من ملف JSON
     */
    suspend fun restoreFromJson(jsonString: String, clearExisting: Boolean = false): BackupResult = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            val familiesArray = root.optJSONArray("families") ?: JSONArray()
            val childrenArray = root.optJSONArray("children") ?: JSONArray()
            val projectsArray = root.optJSONArray("projects") ?: JSONArray()
            val aidRecordsArray = root.optJSONArray("aid_records") ?: JSONArray()

            var restoredFamilies = 0
            var restoredChildren = 0
            var restoredProjects = 0
            var restoredRecords = 0

            // استعادة الأسر
            for (i in 0 until familiesArray.length()) {
                val obj = familiesArray.getJSONObject(i)
                val family = FamilyEntity(
                    familyID = obj.optLong("familyID", 0),
                    name = obj.getString("name"),
                    nationalID = obj.getString("nationalID"),
                    birthDate = obj.optString("birthDate", "1980-01-01"),
                    gender = obj.optString("gender", "ذكر"),
                    maritalStatus = obj.optString("maritalStatus", "متزوج"),
                    familyMembersCount = obj.optInt("familyMembersCount", 6),
                    wifeName = obj.optString("wifeName").takeIf { it.isNotBlank() },
                    wifeNationalID = obj.optString("wifeNationalID").takeIf { it.isNotBlank() },
                    deathStatus = obj.optString("deathStatus", "على قيد الحياة"),
                    developmentApproval = obj.optString("developmentApproval", "معتمد"),
                    localityApproval = obj.optString("localityApproval", "معتمد"),
                    worksApproval = obj.optString("worksApproval", "معتمد أشغال"),
                    residentStatus = obj.optString("residentStatus", "مقيم"),
                    damageType = obj.optString("damageType", "أضرار كلية"),
                    shelterStatus = obj.optString("shelterStatus", "إيواء داخلي"),
                    localityID = obj.optInt("localityID", 1),
                    notes = obj.optString("notes").takeIf { it.isNotBlank() },
                    createdDate = obj.optLong("createdDate", System.currentTimeMillis())
                )
                database.familyDao().insertFamily(family)
                restoredFamilies++
            }

            // استعادة الأطفال
            for (i in 0 until childrenArray.length()) {
                val obj = childrenArray.getJSONObject(i)
                val child = ChildEntity(
                    childID = obj.optLong("childID", 0),
                    nationalID = obj.getString("nationalID"),
                    childName = obj.getString("childName"),
                    birthDate = obj.optString("birthDate", "2020-01-01"),
                    gender = obj.optString("gender", "ذكر"),
                    familyNationalID = obj.getString("familyNationalID"),
                    localityID = obj.optInt("localityID", 1),
                    shelterStatus = obj.optString("shelterStatus", "إيواء داخلي")
                )
                database.childDao().insertChild(child)
                restoredChildren++
            }

            // استعادة المشاريع
            for (i in 0 until projectsArray.length()) {
                val obj = projectsArray.getJSONObject(i)
                val project = ProjectEntity(
                    projectID = obj.optLong("projectID", 0),
                    projectNumber = obj.getString("projectNumber"),
                    projectName = obj.getString("projectName"),
                    aidTypeID = obj.optInt("aidTypeID", 1),
                    detailedDescription = obj.optString("detailedDescription", ""),
                    projectDate = obj.optString("projectDate", "2025-01-01"),
                    fundingInstitution = obj.optString("fundingInstitution", "منحة إغاثية"),
                    quantity = obj.optInt("quantity", 100),
                    isActive = true
                )
                database.projectDao().insertProject(project)
                restoredProjects++
            }

            // استعادة سجلات المساعدات
            for (i in 0 until aidRecordsArray.length()) {
                val obj = aidRecordsArray.getJSONObject(i)
                val record = AidRecordEntity(
                    aidRecordID = obj.optLong("aidRecordID", 0),
                    familyID = obj.optLong("familyID"),
                    aidTypeID = obj.optInt("aidTypeID", 1),
                    projectID = obj.optLong("projectID", 1),
                    aidDate = obj.optString("aidDate", "2025-01-01"),
                    selectionDate = obj.optString("selectionDate", "2025-01-01"),
                    recipientStatus = obj.optString("recipientStatus", "مرشح"),
                    warehouse = obj.optString("warehouse", "المستودع الرئيسي"),
                    aidValue = obj.optDouble("aidValue", 50.0)
                )
                database.aidRecordDao().insertAidRecord(record)
                restoredRecords++
            }

            BackupResult(
                success = true,
                message = "تمت استعادة البيانات بنجاح: $restoredFamilies أسرة، $restoredChildren طفلاً، $restoredProjects مشاريع، $restoredRecords سجل مساعدة.",
                metadata = BackupMetadata(
                    exportDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
                    timestamp = System.currentTimeMillis(),
                    totalFamilies = restoredFamilies,
                    totalChildren = restoredChildren,
                    totalAidRecords = restoredRecords,
                    totalProjects = restoredProjects
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "فشلت عملية الاستعادة: ${e.localizedMessage}"
            )
        }
    }

    /**
     * قائمة النسخ الاحتياطية المحلية الموجودة
     */
    fun listExistingBackups(): List<File> {
        val backupDir = File(context.getExternalFilesDir(null), "backups")
        if (!backupDir.exists()) return emptyList()
        return backupDir.listFiles()?.filter { it.extension == "json" || it.extension == "sql" }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
}
