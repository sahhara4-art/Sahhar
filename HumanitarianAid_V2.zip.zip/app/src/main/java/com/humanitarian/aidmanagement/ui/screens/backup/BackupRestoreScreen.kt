package com.humanitarian.aidmanagement.ui.screens.backup

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.backup.BackupResult
import com.humanitarian.aidmanagement.data.backup.DatabaseBackupManager
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    database: AidDatabase,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val backupManager = remember { DatabaseBackupManager(context, database) }
    val scope = rememberCoroutineScope()

    var isProcessing by remember { mutableStateOf(false) }
    var operationResult by remember { mutableStateOf<BackupResult?>(null) }
    var existingBackups by remember { mutableStateOf<List<File>>(emptyList()) }
    var showRestoreConfirmDialog by remember { mutableStateOf<File?>(null) }

    LaunchedEffect(Unit) {
        existingBackups = backupManager.listExistingBackups()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("النسخ الاحتياطي واستعادة البيانات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // بطاقة التوضيح والأمان
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text(
                                text = "حماية البيانات المحلية وتأمين النقل",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "تتيح هذه الشاشة إنشاء نسخة احتياطية محلية من قاعدة بيانات Room بصيغة JSON أو SQL، لاستخدامها في نقل البيانات إلى جهاز آخر أو استرجاعها عند فقدان البيانات.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            lineHeight = MaterialTheme.typography.bodySmall.lineHeight
                        )
                    }
                }
            }

            // عرض نتيجة العملية
            if (operationResult != null) {
                item {
                    val res = operationResult!!
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (res.success) Color(0xFF10B981).copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    imageVector = if (res.success) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (res.success) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                )
                                Text(
                                    text = res.message,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (res.success) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                )
                            }
                            if (res.filePath != null) {
                                Text(
                                    text = "المسار: ${res.filePath}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }
            }

            // قسم التصدير والنسخ الاحتياطي
            item {
                Text(
                    text = "إنشاء نسخة احتياطية جديدة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            // خيار تصدير JSON
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFF0284C7).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.DataObject, contentDescription = null, tint = Color(0xFF0284C7))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تصدير كملف JSON (موصى به)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("ملف مهيكل يحتوي على الأسر والأطفال والمساعدات والمشاريع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    isProcessing = true
                                    operationResult = backupManager.exportToJson()
                                    existingBackups = backupManager.listExistingBackups()
                                    isProcessing = false
                                }
                            },
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                            } else {
                                Icon(Icons.Default.FileDownload, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تصدير نسخة JSON الآن")
                            }
                        }
                    }
                }
            }

            // خيار تصدير SQL Dump
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFF10B981).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF10B981))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("تصدير كملف SQL Dump", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("أوامر SQL قياسية قابلة للتشغيل المباشر على أي قاعدة SQLite", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                            }
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    isProcessing = true
                                    operationResult = backupManager.exportToSql()
                                    existingBackups = backupManager.listExistingBackups()
                                    isProcessing = false
                                }
                            },
                            enabled = !isProcessing,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().height(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                            } else {
                                Icon(Icons.Default.Code, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تصدير أوامر SQL Dump")
                            }
                        }
                    }
                }
            }

            // قسم النسخ الاحتياطية المتوفرة محلياً
            item {
                Text(
                    text = "النسخ الاحتياطية المتوفرة على الهاتف (${existingBackups.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (existingBackups.isEmpty()) {
                item {
                    Text(
                        text = "لا توجد نسخ احتياطية محفوظة حالياً في مجلد التطبيق.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            } else {
                items(existingBackups) { file ->
                    val isJson = file.extension.lowercase() == "json"
                    val formattedDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(file.lastModified()))

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = file.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "الحجم: ${file.length() / 1024} KB • التاريخ: $formattedDate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }

                            if (isJson) {
                                Button(
                                    onClick = { showRestoreConfirmDialog = file },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("استعادة", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة تأكيد الاستعادة
    if (showRestoreConfirmDialog != null) {
        val fileToRestore = showRestoreConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showRestoreConfirmDialog = null },
            title = { Text("تأكيد استعادة النسخة الاحتياطية", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل أنت متأكد من استعادة البيانات من الملف (${fileToRestore.name})؟ سيتم دمج وتحديث بيانات الأسر والأطفال وسجلات المساعدات."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val file = fileToRestore
                        showRestoreConfirmDialog = null
                        scope.launch {
                            isProcessing = true
                            val jsonContent = file.readText(Charsets.UTF_8)
                            operationResult = backupManager.restoreFromJson(jsonContent)
                            isProcessing = false
                        }
                    }
                ) {
                    Text("نعم، استعادة الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreConfirmDialog = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
