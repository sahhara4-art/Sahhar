package com.humanitarian.aidmanagement.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import kotlinx.coroutines.launch

data class AidCategoryUi(
    val id: Int,
    val name: String,
    val count: Int,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    repository: AidRepository,
    onNavigateToFamilies: () -> Unit,
    onNavigateToNomination: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToBackup: () -> Unit = {}
) {
    var stats by remember { mutableStateOf<DashboardStats?>(null) }
    var fromDate by remember { mutableStateOf("2025-01-01") }
    var toDate by remember { mutableStateOf("2025-12-31") }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        stats = repository.getDashboardStats()
    }

    val categories = listOf(
        AidCategoryUi(1, "غذائي", 420, Icons.Default.Restaurant, Color(0xFF10B981)),
        AidCategoryUi(2, "خضروات وفواكه", 280, Icons.Default.Eco, Color(0xFF84CC16)),
        AidCategoryUi(3, "لحوم", 195, Icons.Default.Fastfood, Color(0xFFEF4444)),
        AidCategoryUi(4, "مساعدات نقدية", 310, Icons.Default.Payments, Color(0xFFF59E0B)),
        AidCategoryUi(5, "كسوة", 220, Icons.Default.Checkroom, Color(0xFF6366F1)),
        AidCategoryUi(6, "مساعدات صحية", 150, Icons.Default.LocalHospital, Color(0xFF06B6D4)),
        AidCategoryUi(7, "فرشات وشوادر", 185, Icons.Default.Bed, Color(0xFF8B5CF6)),
        AidCategoryUi(8, "أدوات مطبخ", 95, Icons.Default.SoupKitchen, Color(0xFFEC4899)),
        AidCategoryUi(9, "بامبرز أطفال", 140, Icons.Default.ChildCare, Color(0xFF14B8A6)),
        AidCategoryUi(10, "فارس الشهم", 260, Icons.Default.Shield, Color(0xFF3B82F6)),
        AidCategoryUi(11, "تنمية اجتماعية", 175, Icons.Default.People, Color(0xFFF97316))
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // رأس الصفحة وتحديد نطاق التاريخ
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المؤشرات العامة والتقارير",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        IconButton(
                            onClick = onNavigateToBackup
                        ) {
                            Icon(Icons.Default.Backup, contentDescription = "النسخ الاحتياطي", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Text(
                        text = "متابعة تدفق المساعدات وحالات الإغاثة الميدانية في الوقت الفعلي",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = fromDate,
                            onValueChange = { fromDate = it },
                            label = { Text("من تاريخ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = toDate,
                            onValueChange = { toDate = it },
                            label = { Text("إلى تاريخ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )
                    }
                }
            }
        }

        // شبكة البطاقات الإحصائية الست الرئيسية
        item {
            Text(
                text = "الإحصائيات الرئيسية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        title = "إجمالي الأسر",
                        value = "${stats?.totalFamilies ?: 0}",
                        icon = Icons.Default.FamilyRestroom,
                        color = Color(0xFF0D9488),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToFamilies
                    )
                    StatCard(
                        title = "إجمالي المستفيدين",
                        value = "${stats?.totalBeneficiaries ?: 0}",
                        icon = Icons.Default.Group,
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToFamilies
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        title = "إجمالي المساعدات",
                        value = "${stats?.totalAidRecords ?: 0}",
                        icon = Icons.Default.Inventory2,
                        color = Color(0xFF8B5CF6),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToReports
                    )
                    StatCard(
                        title = "المشاريع المنفذة",
                        value = "${stats?.totalProjects ?: 0}",
                        icon = Icons.Default.AssignmentTurnedIn,
                        color = Color(0xFFF59E0B),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToReports
                    )
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard(
                        title = "عدد المرشحين",
                        value = "${stats?.totalSelectedCandidates ?: 0}",
                        icon = Icons.Default.HowToReg,
                        color = Color(0xFF10B981),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToNomination
                    )
                    StatCard(
                        title = "المستفيدين المستلمين",
                        value = "${stats?.distinctBeneficiaries ?: 0}",
                        icon = Icons.Default.CheckCircle,
                        color = Color(0xFFEC4899),
                        modifier = Modifier.weight(1f),
                        onClick = onNavigateToReports
                    )
                }
            }
        }

        // قسم تصنيفات المساعدات الإحدى عشرة بالترتيب
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تصنيفات المساعدات (11 تصنيفاً)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        TextButton(onClick = onNavigateToNomination) {
                            Text("بدء الترشيح", color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    categories.forEach { category ->
                        CategoryListItem(category = category)
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(26.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun CategoryListItem(category: AidCategoryUi) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(category.color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(category.icon, contentDescription = null, tint = category.color, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = "${category.id}. ${category.name}",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = category.color.copy(alpha = 0.15f)
            ) {
                Text(
                    text = "${category.count} مساعدة",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = category.color,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}
